export { default } from "./(public)/page";
