-- AlterTable
ALTER TABLE "configurators" ALTER COLUMN "isPublished" SET DEFAULT true;
